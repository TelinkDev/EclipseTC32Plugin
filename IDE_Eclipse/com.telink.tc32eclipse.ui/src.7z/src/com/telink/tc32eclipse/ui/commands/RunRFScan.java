/*******************************************************************************
 * 
 * Copyright (c) 2011 Peter Shieh  
 * 
 * This program and the accompanying materials are made
 * available under the terms of the GNU Public License v3
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/gpl.html
 * 
 * Contributors:
 *     Peter Shieh - initial implementation
 *     
 *******************************************************************************/
package com.telink.tc32eclipse.ui.commands;

import java.io.IOException;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import  com.telink.tc32eclipse.core.toolinfo.FindRFScan;


/**
 * @author Peter Shieh
 * @since 1.0
 * @since 2.3 Added optional delay between TCDB invocations
 * 
 */

public class RunRFScan extends AbstractHandler {

	  public Object execute(ExecutionEvent event) throws ExecutionException {
		
		
	      FindRFScan tools = FindRFScan.getDefault();
		
		try {
		    tools.run("");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	    //HandlerUtil.getActiveWorkbenchWindow(event).close();
	    return null;
	  }
	  

	} 




